<?php
return [
    'db.host' => 'localhost',
    'db.user' => 'likhon',
    'db.password' => '123456',
    'db.name' => 'devx',

    'rabbit.host' => 'localhost',
    'rabbit.user' => 'likhon',
    'rabbit.password' => '123456',
    'rabbit.port' => 5672,

    'redis.host' => '127.0.0.1',

    'registermo' => __DIR__.'/registermo',

    'daemon.count' => 100
];